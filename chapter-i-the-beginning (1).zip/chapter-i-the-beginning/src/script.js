const GuestBtn = document.getElementById('guestbttn');

const GuestAlert = document.getElementById('guestalert');

const Guestconfirm = document.getElementById('ok');

GuestBtn.addEventListener('click', function(){
  guestalert.style.display='flex';
});

Guestconfirm.addEventListener('click', function(){
  guestalert.style.display='none'
});



const chancealertBtn = document.getElementById('chancebttn');

const chancealert = document.getElementById('chancealert');

const chanceconfirm = document.getElementById('I');

const customalert2 = document.getElementById('chancealert2')

const customalert3 = document.getElementById('chancealert3')

const nextdialogbttn = document.getElementById('Yes')



chancealertBtn.addEventListener('click', function(){
  chancealert.style.display='flex';
});

chanceconfirm.addEventListener('click', function(){
  chancealert.style.display='none'
 chancealert2.style.display='flex'
});

nextdialogbttn.addEventListener('click', function(){
 chancealert2.style.display='none' 
 chancealert3.style.display='flex'
})