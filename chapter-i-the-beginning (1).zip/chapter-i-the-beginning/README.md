# Chapter I: The Beginning

A Pen created on CodePen.

Original URL: [https://codepen.io/Remain-Zero/pen/LEpjdRY](https://codepen.io/Remain-Zero/pen/LEpjdRY).

